from queuelib.queue import FifoDiskQueue, LifoDiskQueue
from queuelib.pqueue import PriorityQueue
from queuelib.rrqueue import RoundRobinQueue